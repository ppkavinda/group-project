// http://eslint.org/docs/user-guide/configuring

module.exports = {
  "extends": [
    'plugin:vue/essential',
    '@vue/standard'
  ],

  root: true
};
