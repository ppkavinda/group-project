// vue.config.js
module.exports = {
  lintOnSave: true
}
